/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.usoarreglos;

import java.util.Scanner;

/**
 *
 * @author leona
 */
public class UsoArreglos {

    public static void main(String[] args) {
        //PromedioArreglo();
        //ValorEspecifico();
        //MaxMin();
        //NumMayor();
        //Arreglar();
    }

    public static void PromedioArreglo() {
        Scanner input = new Scanner(System.in);
        System.out.print("Ingrese el tamaño del arreglo: ");
        int n = input.nextInt();

        //Crear el arreglo
        int[] arr = new int[n];

        // Pedir al usuario que ingrese los elementos del arreglo
        System.out.println("Ingrese los elementos del arreglo: ");
        for (int i = 0; i < n; i++) {
            arr[i] = input.nextInt();
        }

        // Calcular el promedio
        double promedio = 0;
        for (int i = 0; i < n; i++) {
            promedio += arr[i];
        }
        promedio /= n;

        System.out.println("El promedio de los elementos del arreglo es: " + promedio);
    }

    public static void ValorEspecifico() {
        Scanner input = new Scanner(System.in);
        System.out.print("Ingrese el tamaño del arreglo: ");
        int n = input.nextInt();

        int[] arr = new int[n];

        System.out.println("Ingrese los elementos del arreglo: ");
        for (int i = 0; i < n; i++) {
            arr[i] = input.nextInt();
        }

        // Pedir al usuario que ingrese el valor a buscar
        System.out.print("Ingrese el valor a buscar: ");
        int valorBuscado = input.nextInt();

        // Comprobar si el valor está en el arreglo
        boolean encontrado = false;
        for (int i = 0; i < n; i++) {
            if (arr[i] == valorBuscado) {
                encontrado = true;
                break;
            }
        }

        if (encontrado) {
            System.out.println("El valor " + valorBuscado + " está en el arreglo.");
        } else {
            System.out.println("El valor " + valorBuscado + " no está en el arreglo.");
        }

    }

    public static void MaxMin() {
        Scanner input = new Scanner(System.in);
        System.out.print("Ingrese el tamaño del arreglo: ");
        int n = input.nextInt();

        int[] arr = new int[n];

        System.out.println("Ingrese los elementos del arreglo: ");
        for (int i = 0; i < n; i++) {
            arr[i] = input.nextInt();
        }

        // Encontrar el valor máximo y mínimo
        int maximo = arr[0];
        int minimo = arr[0];
        for (int i = 1; i < n; i++) {
            if (arr[i] > maximo) {
                maximo = arr[i];
            }
            if (arr[i] < minimo) {
                minimo = arr[i];
            }
        }

        System.out.println("El valor máximo del arreglo es: " + maximo);
        System.out.println("El valor mínimo del arreglo es: " + minimo);
    }

    public static void NumMayor() {
        Scanner input = new Scanner(System.in);
        System.out.print("Ingrese el tamaño del arreglo: ");
        int n = input.nextInt();

        int[] arr = new int[n];

        System.out.println("Ingrese los elementos del arreglo: ");
        for (int i = 0; i < n; i++) {
            arr[i] = input.nextInt();
        }

        // Calcular el promedio de los elementos del arreglo
        int suma = 0;
        for (int i = 0; i < n; i++) {
            suma += arr[i];
        }
        double promedio = (double) suma / n;

        // Contar la cantidad de números mayores que el promedio
        int contador = 0;
        for (int i = 0; i < n; i++) {
            if (arr[i] > promedio) {
                contador++;
            }
        }

        System.out.println("La cantidad de números mayores que el promedio es: " + contador);
    }

    public static void Arreglar() {
        Scanner input = new Scanner(System.in);
        System.out.print("Ingrese el tamaño del arreglo: ");
        int n = input.nextInt();

        int[] arr = new int[n];

        System.out.println("Ingrese los elementos del arreglo: ");
        for (int i = 0; i < n; i++) {
            arr[i] = input.nextInt();
        }

        // Verificar si el arreglo está ordenado en orden ascendente
        boolean ordenado = true;
        for (int i = 0; i < n - 1; i++) {
            if (arr[i] > arr[i + 1]) {
                ordenado = false;
                break;
            }
        }

        if (ordenado) {
            System.out.println("El arreglo está ordenado en orden ascendente");
        } else {
            System.out.println("El arreglo no está ordenado en orden ascendente");
        }
    }
}
